﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProtectWizardTests.StepsProtectWizard
{
    class EncryptionStep : StepBase
    {
        public EncryptionStep(IWebDriver driver)
            : base(driver)
        {
        }


        public override StepBase GetNext()
        {
            throw new NotImplementedException();
        }

        public override StepBase GoToThisStep(ProtectionType type)
        {
            throw new NotImplementedException();
        }

    }
}
