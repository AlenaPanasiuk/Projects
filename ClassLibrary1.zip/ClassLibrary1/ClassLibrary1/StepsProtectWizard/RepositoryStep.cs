﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtectWizardTests.StepsProtectWizard;

namespace ProtectWizardTests.StepsProtectWizard
{
    class RepositoryStep : StepBase
    {
        public RepositoryStep(IWebDriver driver)
            : base(driver)
        {
        }

        public override StepBase GetNext()
        {
            if (GetStepId() == "encryption")
            {
                return new EncryptionStep(driver);
            }
            else if (GetStepId() == "repoConfiguration")
            {
                return new ConfigurationStep(driver);
            }
            return this;
        }
       
        public override StepBase GoToThisStep(ProtectionType type)
        {

                ScheduleStep schedule = new ScheduleStep(driver);
                schedule.GoToThisStep(type);
                schedule.SetValidData();
               var repository = (RepositoryStep)schedule.GoNext();

            return repository;
        }


        public override void SetValidData()
        {
            SetRepository(RepositoryNewOrExisting.New, RepositoryLocationType.Local, @"C:\repoTest", "", "", @"C:\repoTestMetadata");
 
        }

        public void SetRepository(RepositoryNewOrExisting repositoryNewOrExisting, RepositoryLocationType locationtype, string location, string user, string password, string locationMetadata )
        {
            if (repositoryNewOrExisting == RepositoryNewOrExisting.New)
            {
                driver.FindElement(By.Id("createRepository")).Click();
                driver.FindElement(By.Id("newRepoName")).SendKeys("newTestRepo");
                driver.FindElement(By.Id("newRepoLocation")).SendKeys(location);
               
                if (locationtype == RepositoryLocationType.CIFS)
                {
                    driver.FindElement(By.Id("newRepoUserName")).SendKeys(user); 
                        driver.FindElement(By.Id("newRepoPassword")).SendKeys(password);
                }
                if (locationtype == RepositoryLocationType.Local)
                {
                    driver.FindElement(By.Id("newRepoMetadataLocation")).SendKeys(locationMetadata);

                }
            }

            if (repositoryNewOrExisting == RepositoryNewOrExisting.Existing)
            {
                driver.FindElement(By.Id("dropdown-visual-input-existedRepositories")).Click();
                IList<IWebElement> listrepositories = driver.FindElement(By.Id("existedRepositories")).FindElements(By.TagName("option"));
                listrepositories.Last().Click();
              
               
            }
        }

        public void SetRepository(RepositoryNewOrExisting repositoryNewOrExisting)
        {
            SetRepository(repositoryNewOrExisting, RepositoryLocationType.Local, "", "", "", "");
        }

    }

    public enum RepositoryNewOrExisting
    {
        New,
        Existing
    }

    public enum RepositoryLocationType
    {
        Local,
        CIFS,
        None
    }
}
