﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ProtectWizardTests.StepsProtectWizard
{
    class ConfigurationStep : StepBase
    {
        public ConfigurationStep(IWebDriver driver)
            : base(driver)
        {
        }

        public override StepBase GetNext()
        {
            return new EncryptionStep(driver);
        }

        public override StepBase GoToThisStep(ProtectionType type)
        {
            RepositoryStep repository = new RepositoryStep(driver);
            repository.GoToThisStep(type);
            repository.SetValidData();
            var next = repository.GoNext();
            return (ConfigurationStep)next;
        }

        public void SetConfiguration(string size, bool advancedOptions)
        {

            SetConfiguration(size, false, BytesPerSector.Bytes512);

        }

        public void SetConfiguration(string size, bool advancedOptions, BytesPerSector bytesPerSector)
        {
            SetConfiguration (size, advancedOptions);
            driver.FindElement(By.Id("repoConfigSize")).SendKeys(size);
            if (advancedOptions)
            {
                driver.FindElement(By.Id("toggleRepoAdvancedConfiguration")).Click();

            }



        }



    }

    public enum BytesPerSector
    {
        Bytes512,
        Bytes1024,
        Bytes2048,
        Bytes4096
    }


}
