﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtectWizardTests.StepsProtectWizard;

namespace ProtectWizardTests.StepsProtectWizard
{
    class ScheduleStep : StepBase
    {
        public ScheduleStep(IWebDriver driver)
            : base(driver)
        {
        }

        public override StepBase GetNext()
        {
            return new RepositoryStep(driver);
        }



        public override StepBase GoToThisStep(ProtectionType type)
        {
            VolumesStep volumesstep = new VolumesStep(driver);
            volumesstep.GoToThisStep(type);
            volumesstep.SetValidData();
            volumesstep.GoNext();
            return new ScheduleStep(driver);
        }

        public override void SetValidData()
        {
            SetSchedulePeriods(true, true, false, "12:00 AM", "11:59 PM", "60", "60", "60", false);
        }

        public void SetSchedulePeriods(bool weekdays, bool weekends, bool protectWeekdaysRest, string from, string to, string weekdaysPeriopd, string weekendsPeriod, string weekdaysRestPeriod, bool pause)
        {
            driver.FindElement(By.Id("periods")).Click();
            if (pause)
            {
                driver.FindElement(By.Id("initialPauseProtection")).Click();
            }
            if (weekdays)
            {
                driver.FindElement(By.Id("weekdaysFrom")).FindElement(By.TagName("input")).Clear();
                driver.FindElement(By.Id("weekdaysFrom")).FindElement(By.TagName("input")).SendKeys(from);

                driver.FindElement(By.Id("weekdaysTo")).FindElement(By.TagName("input")).Clear();
                driver.FindElement(By.Id("weekdaysTo")).FindElement(By.TagName("input")).SendKeys(to);

                driver.FindElement(By.Id("weekdaysPeriod")).Clear();
                driver.FindElement(By.Id("weekdaysPeriod")).SendKeys(weekdaysPeriopd);
                if (protectWeekdaysRest)
                {
                    driver.FindElement(By.Id("protectWeekdaysRest")).Click();
                    driver.FindElement(By.Id("weekdaysRestPeriod")).Clear();
                    driver.FindElement(By.Id("weekdaysRestPeriod")).SendKeys(weekdaysRestPeriod);

                }
            }
            else 
            {
                driver.FindElement(By.Id("protectWeekdays")).Click();
            }
            if (weekends)
            {
                driver.FindElement(By.Id("weekendsPeriod")).Clear();
                driver.FindElement(By.Id("weekendsPeriod")).SendKeys(weekendsPeriod);
            }
            else 
            {
                driver.FindElement(By.Id("protectWeekends")).Click();
            }

        }
        public void SetScheduleDaily(string protectionTime, bool pause)
        {
            if (pause)
            {
                driver.FindElement(By.Id("initialPauseProtection")).Click();
            }
            driver.FindElement(By.Id("protectionTime")).Click();
            driver.FindElement(By.Id("dailyProtection")).FindElement(By.TagName("input")).Clear();
            driver.FindElement(By.Id("dailyProtection")).FindElement(By.TagName("input")).SendKeys(protectionTime);

        }


    }
}
